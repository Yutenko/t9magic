import{a as t}from"../chunks/entry.BVl3iVmE.js";export{t as start};
