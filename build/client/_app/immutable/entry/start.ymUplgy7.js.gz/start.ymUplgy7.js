import{a as t}from"../chunks/entry.Bp_ia5kQ.js";export{t as start};
